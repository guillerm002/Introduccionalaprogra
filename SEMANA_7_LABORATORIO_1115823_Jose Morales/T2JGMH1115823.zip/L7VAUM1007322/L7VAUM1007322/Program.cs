﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L7VAUM1007322
{
    class Program
    {

        static void Main(string[] args)
        {

            float vi=0;
            float vf=0;
            float a=0;
            float t=0;
            string entrada = "";
            int varCalcular = 0;
            int contVarCalcular = 0;
            int errorValores = 0;


            Console.Out.WriteLine("********** Movimiento Rectilineo Uniformemente Variado (MRUV) **********");
            
            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Ecuación: Vf = Vi + at");
            Console.Out.WriteLine("Vf = Velocidad Final");
            Console.Out.WriteLine("Vi = Velocidad Inicial");
            Console.Out.WriteLine("a = Aceleración");
            Console.Out.WriteLine("t = Tiempo");

            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Instrucciones: En la variable que se desea calcular unicamente presionar Enter (no ingresar valores)");
            Console.Out.WriteLine("\n");

                     

            Console.Out.WriteLine("Ingrese Velocidad Final (m/s) ");
            entrada = Console.ReadLine();
            //Se valida si se ingresaron datos.
            if (string.IsNullOrEmpty(entrada))
            {
                varCalcular = 1;
                contVarCalcular += 1;
            }
            else
            {
                //Se valida si el dato ingresado es válido, si es valido se asigna a la variable
                if (!(float.TryParse(entrada, out vf)))
                {
                    errorValores += 1; 
                };
            }

            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Ingrese Velocidad Inicial (m/s) ");
            entrada = Console.ReadLine();
            //Se valida si se ingresaron datos.
            if (string.IsNullOrEmpty(entrada))
            {
                varCalcular = 2;
                contVarCalcular += 1;
            }
            else
            {
                //Se valida si el dato ingresado es válido, si es valido se asigna a la variable
                if (!(float.TryParse(entrada, out vi)))
                {
                    errorValores += 1;
                };
            }

            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Ingrese Aceleración (m/s^2) ");
            entrada = Console.ReadLine();
            //Se valida si se ingresaron datos.
            if (string.IsNullOrEmpty(entrada))
            {
                varCalcular = 3;
                contVarCalcular += 1;
            }
            else
            {
                //Se valida si el dato ingresado es válido, si es valido se asigna a la variable
                if (!(float.TryParse(entrada, out a)))
                {
                    errorValores += 1;
                };
            }

            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Ingrese Tiempo (s) ");
            entrada = Console.ReadLine();
            //Se valida si se ingresaron datos.
            if (string.IsNullOrEmpty(entrada))
            {
                varCalcular = 4;
                contVarCalcular += 1;
            }
            else
            {
                //Se valida si el dato ingresado es válido, si es valido se asigna a la variable
                if (!(float.TryParse(entrada, out t)))
                {
                    errorValores += 1;
                };
            }

            Console.Out.WriteLine("\n");
            //Se valida que se haya definido la variable a calcular
            if (contVarCalcular == 1)
            {
                //Se valida que no existan error en los valores ingresados
                if (errorValores == 0)
                {
                    
                    //Se verifica la variable a calcular para aplicar la fórmula correspondiente
                    if (varCalcular == 1)
                    {
                        //Calcular velocidad Final
                        vf = vi + (a * t);
                        Console.Out.WriteLine(String.Format("Resultado Velocidad Final: Vf = {0} m/s", Math.Round(vf,2)));
                    }
                    else if (varCalcular == 2)
                    {
                        //Calcular velocidad inicial
                        vi = (vf - (a * t));
                        Console.Out.WriteLine(String.Format("Resultado Velocidad Inicial: Vi = {0} m/s", Math.Round(vi,2)));
                    }
                    else if (varCalcular == 3)
                    {
                        //Calcular aceleración
                        a = ((vf - vi) / t);
                        Console.Out.WriteLine(String.Format("Resultado Aceleración: a = {0} m/s^2", Math.Round(a,2)));
                    }
                    else if (varCalcular == 4)
                    {
                        //Calcular tiempo
                        t = ((vf - vi) / a);
                        Console.Out.WriteLine(String.Format("Resultado Tiempo: t = {0} s", Math.Round(t,2)));
                    }
                }
                else
                {
                    Console.Out.WriteLine("Error: Valor asignado a variable(s) incorrecto, verificar."); 
                }
                    
            }
            else
            {
                Console.Out.WriteLine("Error: No se estableció la variable a calcular, verificar.");                
            }


            Console.Out.WriteLine("\n");
            Console.Out.WriteLine("Presione una tecla para salir.");  
            Console.ReadKey();

        }
    }
}
